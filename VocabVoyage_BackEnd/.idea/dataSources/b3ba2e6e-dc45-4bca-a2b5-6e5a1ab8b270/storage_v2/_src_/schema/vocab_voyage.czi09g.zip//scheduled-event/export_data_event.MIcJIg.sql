create definer = root@`%` event export_data_event on schedule
    every '24' HOUR
        starts '2024-11-11 01:00:00'
    enable
    do
    BEGIN
        -- 获取当前时间并格式化为合适的字符串格式，用于文件名
        SET @date_time_str = DATE_FORMAT(NOW(), '%Y-%m-%d_%H-%i-%s');
        -- 拼接文件名，包含路径、表名、时间标识以及文件扩展名
        SET @filename = CONCAT('/var/lib/mysql-files/word_', @date_time_str, '.csv');
        -- 构建动态SQL语句，注意对文件名变量的使用方式做了调整
        SET @sql = CONCAT('SELECT * INTO OUTFILE ', QUOTE(@filename), '
        FIELDS TERMINATED BY '',''
        ENCLOSED BY ''"''
        LINES TERMINATED BY ''\n''
        FROM word');
        -- 准备执行动态SQL语句
        PREPARE stmt FROM @sql;
        -- 执行动态SQL语句
        EXECUTE stmt;
        -- 释放动态SQL语句资源
        DEALLOCATE PREPARE stmt;
    END;

