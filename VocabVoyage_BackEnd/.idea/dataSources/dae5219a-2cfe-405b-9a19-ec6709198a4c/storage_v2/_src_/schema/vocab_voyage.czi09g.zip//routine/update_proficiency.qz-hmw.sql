create
    definer = root@`%` procedure update_proficiency(IN p_word_id int, IN p_user_id int, IN mem_res int)
BEGIN
    DECLARE current_proficiency INT DEFAULT 0;
    -- 尝试获取当前熟练度，如果不存在则设置为默认值
    SELECT proficiency INTO current_proficiency
    FROM memory
    WHERE user_id = p_user_id AND word_id = p_word_id;
    -- 根据记忆结果更新熟练度
    CASE mem_res
        WHEN 1 THEN
            SET current_proficiency = FLOOR(current_proficiency * 0.7 + 100 * 0.3);
        WHEN 2 THEN
            SET current_proficiency = FLOOR(current_proficiency * 0.9);
        WHEN 3 THEN
            SET current_proficiency = FLOOR(current_proficiency * 0.3);
        ELSE
            -- 如果 mem_res 不是 1、2 或 3，可以设置为默认值或抛出错误
            SET current_proficiency = 0; -- 或者可以选择抛出错误
        END CASE;
    -- 如果用户和单词都存在，更新熟练度和最后记忆时间；否则插入新记录，熟练度设为 6
    IF EXISTS (SELECT 1 FROM memory WHERE user_id = p_user_id AND word_id = p_word_id) THEN
        UPDATE memory
        SET proficiency = current_proficiency, last_memory_time = CURDATE()
        WHERE user_id = p_user_id AND word_id = p_word_id;
    ELSE
        INSERT INTO memory (user_id, word_id, last_memory_time, proficiency)
        VALUES (p_user_id, p_word_id, CURDATE(), current_proficiency);
    END IF;
END;

