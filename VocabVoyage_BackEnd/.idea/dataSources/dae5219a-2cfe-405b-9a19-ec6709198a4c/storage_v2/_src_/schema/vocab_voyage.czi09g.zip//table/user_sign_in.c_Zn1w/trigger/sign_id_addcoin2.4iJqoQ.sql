create definer = root@`%` trigger sign_id_addcoin2
    after insert
    on user_sign_in
    for each row
BEGIN
	Update user
	set coin = coin + 1
	where user.id = New.user_id;
END;

