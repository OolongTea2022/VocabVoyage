create definer = root@`%` view user_word_stats as
select `u`.`id`               AS `user_id`,
       count(`m`.`id`)        AS `total_memorized_words`,
       avg(`m`.`proficiency`) AS `average_proficiency`
from (`vocab_voyage`.`user` `u` join `vocab_voyage`.`memory` `m` on ((`u`.`id` = `m`.`user_id`)))
group by `u`.`id`;

-- comment on column user_word_stats.user_id not supported: 用户ID

